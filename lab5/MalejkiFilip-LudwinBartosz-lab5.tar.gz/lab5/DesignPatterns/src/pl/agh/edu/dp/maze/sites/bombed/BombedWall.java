package pl.agh.edu.dp.maze.sites.bombed;

import pl.agh.edu.dp.maze.sites.standard.Wall;

public class BombedWall extends Wall {
}
