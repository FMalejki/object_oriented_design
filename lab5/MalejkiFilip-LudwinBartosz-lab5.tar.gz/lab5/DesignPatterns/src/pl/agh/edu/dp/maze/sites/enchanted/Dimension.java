package pl.agh.edu.dp.maze.sites.enchanted;

import pl.agh.edu.dp.maze.sites.standard.Room;

public class Dimension extends Room {
    public Dimension(int number) {
        super(number);
    }
}
