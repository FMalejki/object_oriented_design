package pl.agh.edu.dp.maze.sites.standard;

import pl.agh.edu.dp.maze.sites.MapSite;

public class Wall extends MapSite {
    public Wall(){

    }

    @Override
    public void Enter(){

    }
}
