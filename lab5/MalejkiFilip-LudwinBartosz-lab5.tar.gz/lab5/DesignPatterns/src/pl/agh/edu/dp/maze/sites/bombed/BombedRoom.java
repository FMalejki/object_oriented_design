package pl.agh.edu.dp.maze.sites.bombed;

import pl.agh.edu.dp.maze.sites.standard.Room;

public class BombedRoom extends Room {
    public BombedRoom(int number) {
        super(number);
    }
}
