package pl.agh.edu.dp.maze.sites.enchanted;

import pl.agh.edu.dp.maze.sites.standard.Wall;

public class MagicBarrier extends Wall {
}
