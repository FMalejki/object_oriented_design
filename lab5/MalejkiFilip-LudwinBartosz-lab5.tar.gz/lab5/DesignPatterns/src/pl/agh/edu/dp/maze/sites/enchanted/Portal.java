package pl.agh.edu.dp.maze.sites.enchanted;

import pl.agh.edu.dp.maze.sites.standard.Door;
import pl.agh.edu.dp.maze.sites.standard.Room;

public class Portal extends Door {
    public Portal(Room r1, Room r2) {
        super(r1, r2);
    }
}
