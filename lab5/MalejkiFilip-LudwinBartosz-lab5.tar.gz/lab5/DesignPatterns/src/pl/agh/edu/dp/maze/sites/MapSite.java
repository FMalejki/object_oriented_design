package pl.agh.edu.dp.maze.sites;

public abstract class MapSite {
    public abstract void Enter();
}
