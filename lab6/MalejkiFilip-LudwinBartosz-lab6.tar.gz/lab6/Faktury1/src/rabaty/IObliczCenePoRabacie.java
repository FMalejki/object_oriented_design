package rabaty;

public interface IObliczCenePoRabacie {
	double obliczCenePoRabacie(double cena);
}
