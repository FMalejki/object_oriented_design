package raporty;

public class StandardPrinter extends FakturaPrinterTemplate {

}
